
export interface Product {
  id: string;
  productName: string;
  productionDate: string;
  expireDate: string;
  albaikExpire: string;
  quantityCarton?: number;
  quantityPiece?: number;
}
