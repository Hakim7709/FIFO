
export const productNames = [
  "Garlic Small",
  "Garlic Large",
  "Nugget Small",
  "Nugget Large",
  "Cocktail Small",
  "Cocktail Large",
  "Tahina Small",
  "Tartar Small",
  "TAHINA Large",
  "Garlic Super",
  "Burger Super Regular",
  "Burger Super Spicy",
  "Tahina Super",
  "Tartar Super",
  "Fish Super",
  "Pickle Regular",
  "Pickle Spicy",
  "Sweet Pickle",
  "Diced Pickle"
];
