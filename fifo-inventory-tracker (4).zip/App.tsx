import React, { useState, useEffect, useCallback } from 'react';
import { Product } from './types';
import ProductForm from './components/ProductForm';
import ProductList from './components/ProductList';

const App: React.FC = () => {
  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const savedProducts = localStorage.getItem('fifoProducts');
      const productsFromStorage = savedProducts ? JSON.parse(savedProducts) : [];
      
      // One-time migration for old data structure
      if (productsFromStorage.length > 0 && productsFromStorage[0].quantity !== undefined) {
        const migratedProducts = productsFromStorage.map((p: any) => {
          const { quantity, ...rest } = p;
          return {
            ...rest,
            quantityCarton: quantity,
            quantityPiece: 0
          };
        });
        localStorage.setItem('fifoProducts', JSON.stringify(migratedProducts));
        return migratedProducts;
      }

      return productsFromStorage;
    } catch (error) {
      console.error("Could not parse products from localStorage", error);
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('fifoProducts', JSON.stringify(products));
    } catch (error) {
      console.error("Could not save products to localStorage", error);
    }
  }, [products]);

  const addProduct = useCallback((product: Omit<Product, 'id'>) => {
    const newProduct: Product = {
      ...product,
      id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    };
    setProducts(prevProducts => [...prevProducts, newProduct]);
  }, []);

  const deleteProduct = useCallback((id: string) => {
    setProducts(prevProducts => prevProducts.filter(p => p.id !== id));
  }, []);

  const clearAllProducts = useCallback(() => {
    if (window.confirm('Are you sure you want to delete all products? This action cannot be undone.')) {
        setProducts([]);
    }
  }, []);

  return (
    <div className="min-h-screen bg-slate-50">
      <main className="container mx-auto px-4 py-8 md:py-12">
        <header className="text-center mb-8 md:mb-12">
          <img src="/albaik-logo.png" alt="Albaik Logo" className="mx-auto mb-4 w-32 h-auto md:w-40" />
          <h1 className="text-4xl md:text-5xl font-bold text-slate-800 tracking-tight">
            Albaik Food Systems Company
          </h1>
          <p className="text-lg text-slate-500 max-w-2xl mx-auto mt-2">
            Devoloved By ''MD HAKIM MIA''
          </p>
        </header>

        <section className="mb-12">
          <ProductForm onAddProduct={addProduct} />
        </section>

        <section>
          <ProductList products={products} onDeleteProduct={deleteProduct} onClearAll={clearAllProducts} />
        </section>
      </main>
      <footer className="text-center py-6 text-sm text-slate-400">
        <p>Built with React & Tailwind CSS</p>
      </footer>
    </div>
  );
};

export default App;
