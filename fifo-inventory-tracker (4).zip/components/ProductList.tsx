
import React from 'react';
import { Product } from '../types';
import { TrashIcon, WarningIcon, ShareIcon } from './icons';
import { productNames } from '../data';

interface ProductListProps {
  products: Product[];
  onDeleteProduct: (id: string) => void;
  onClearAll: () => void;
}

const calculateRemainingDays = (dateString: string): number => {
  if (!dateString) return 0;
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const parts = dateString.split('-').map(Number);
  const expiry = new Date(parts[0], parts[1] - 1, parts[2]);

  const diffTime = expiry.getTime() - today.getTime();
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
};

const formatDate = (dateString: string): string => {
  if (!dateString) return 'N/A';
  const date = new Date(dateString);
  const correctedDate = new Date(date.getTime() + date.getTimezoneOffset() * 60000);
  return correctedDate.toLocaleDateString('en-CA');
};

const getOrdinalSuffix = (n: number): string => {
    if (n > 3 && n < 21) return 'th';
    switch (n % 10) {
        case 1: return 'st';
        case 2: return 'nd';
        case 3: return 'rd';
        default: return 'th';
    }
};

const getProductEmoji = (productName: string): string => {
    const lowerCaseName = productName.toLowerCase();
    if (lowerCaseName.includes('garlic')) return '🧄';
    if (lowerCaseName.includes('nugget')) return '🍗';
    if (lowerCaseName.includes('cocktail')) return '🍹';
    if (lowerCaseName.includes('tartar')) return '🥫';
    if (lowerCaseName.includes('tahina')) return '🌿';
    if (lowerCaseName.includes('burger')) return '🍔';
    if (lowerCaseName.includes('fish')) return '🐟';
    if (lowerCaseName.includes('pickle')) {
        if (lowerCaseName.includes('spicy')) return '🌶';
        if (lowerCaseName.includes('sweet')) return '🍬';
        return '🥒';
    }
    return '📦';
};

const formatReportDate = (dateString: string): string => {
    if (!dateString) return '';
    const date = new Date(dateString);
    const correctedDate = new Date(date.getTime() + date.getTimezoneOffset() * 60000);
    const day = correctedDate.getDate();
    const month = correctedDate.toLocaleString('en-US', { month: 'short' });
    const year = correctedDate.getFullYear();
    return `${day}-${month}-${year}`;
};


const RemainingDaysDisplay: React.FC<{ days: number }> = ({ days }) => {
    let textColor = 'text-green-600';
    if (days <= 0) {
        textColor = 'text-red-600';
    } else if (days <= 7) {
        textColor = 'text-amber-600';
    }

    return (
        <span className={`font-semibold ${textColor}`}>
            {days}
        </span>
    );
};

const formatQuantity = (cartons?: number, pieces?: number, short = false): string => {
    const ctnText = short ? 'Ctn' : 'Cartons';
    const pcsText = short ? 'Pcs' : 'Pieces';
    const cartonStr = cartons ? `${cartons} ${ctnText}` : '';
    const pieceStr = pieces ? `${pieces} ${pcsText}` : '';
    return [cartonStr, pieceStr].filter(Boolean).join(', ') || 'N/A';
};


const ProductList: React.FC<ProductListProps> = ({ products, onDeleteProduct, onClearAll }) => {
  const sortedProducts = [...products].sort((a, b) => {
    const dateA = a.albaikExpire ? new Date(a.albaikExpire).getTime() : Infinity;
    const dateB = b.albaikExpire ? new Date(b.albaikExpire).getTime() : Infinity;
    return dateA - dateB;
  });
  
  const productNameCounts = products.reduce((acc, product) => {
      acc[product.productName] = (acc[product.productName] || 0) + 1;
      return acc;
  }, {} as Record<string, number>);

  const usageOrderMap = new Map<string, string>();
  const rankTracker = new Map<string, number>();

  sortedProducts.forEach(product => {
      if (productNameCounts[product.productName] > 1) {
          const rank = (rankTracker.get(product.productName) || 0) + 1;
          rankTracker.set(product.productName, rank);
          const label = `${rank}${getOrdinalSuffix(rank)} Use`;
          usageOrderMap.set(product.id, label);
      }
  });

  const generateReport = (): string => {
    const today = new Date();
    const headerDate = today.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
    let report = `📅 Date Summary – ${headerDate}\n\n⸻\n\n`;

    const productGroups: Record<string, Product[]> = {};
    for (const product of products) {
        if (!productGroups[product.productName]) {
            productGroups[product.productName] = [];
        }
        productGroups[product.productName].push(product);
    }

    productNames.forEach(name => {
        const matchingProducts = productGroups[name];
        if (matchingProducts && matchingProducts.length > 0) {
            matchingProducts.sort((a, b) => new Date(a.albaikExpire).getTime() - new Date(b.albaikExpire).getTime());
            
            matchingProducts.forEach((product, index) => {
                let productNameLabel = `${getProductEmoji(name)} ${product.productName}`;
                if (matchingProducts.length > 1) {
                    if (index === 0) {
                        // Don't add a suffix to the first item
                    } else if (index === 1) {
                        productNameLabel += ` (2nd Beach)`;
                    } else {
                        const rank = index + 1;
                        productNameLabel += ` (${rank}${getOrdinalSuffix(rank)} Beach)`;
                    }
                }

                const remaining = calculateRemainingDays(product.albaikExpire);
                const remainingText = remaining <= 0 
                    ? `🔴 Remains Days: ${remaining} (Expired)`
                    : `🕒 Remains Days: ${remaining}`;

                report += `${productNameLabel}\n`;
                report += `📆 Production Date: ${formatReportDate(product.productionDate)}\n`;
                report += `❌ Expire: ${formatReportDate(product.expireDate)}\n`;
                report += `🖨 Printed Expire: ${formatReportDate(product.albaikExpire)}\n`;
                report += `${remainingText}\n`;
                report += `🔢 Quantity: ${formatQuantity(product.quantityCarton, product.quantityPiece)}\n\n`;
            });
        }
    });

    return report.trim();
  };

  const handleShare = async () => {
    if (products.length === 0) {
        alert("There are no products to share.");
        return;
    }
    const reportText = generateReport();
    const reportTitle = 'Albaik Inventory Report';

    if (navigator.share) {
        try {
            await navigator.share({
                title: reportTitle,
                text: reportText,
            });
        } catch (error) {
            console.error('Share failed:', error);
        }
    } else {
        try {
            await navigator.clipboard.writeText(reportText);
            alert('Report copied to clipboard! You can now paste it in any application.');
        } catch (err) {
            console.error('Failed to copy report:', err);
            alert('Could not copy report to clipboard.');
        }
    }
  };

  if (products.length === 0) {
    return (
      <div className="text-center py-16 px-6 bg-white rounded-xl shadow-md border border-slate-200">
        <h3 className="text-xl font-semibold text-slate-700">No Products Yet</h3>
        <p className="text-slate-500 mt-2">Add a product using the form above to get started.</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-md border border-slate-200 overflow-hidden">
        <div className="p-4 md:p-6 flex flex-wrap justify-between items-center gap-4 border-b border-slate-200">
            <h2 className="text-2xl font-bold text-slate-700">Inventory List</h2>
            <div className="flex items-center gap-2">
                <button
                    onClick={handleShare}
                    className="flex items-center gap-2 px-4 py-2 bg-green-50 text-green-600 font-semibold rounded-lg hover:bg-green-100 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 transition-colors text-sm"
                    aria-label="Share inventory report"
                >
                    <ShareIcon className="w-4 h-4" />
                    Share Report
                </button>
                <button
                    onClick={onClearAll}
                    className="flex items-center gap-2 px-4 py-2 bg-red-50 text-red-600 font-semibold rounded-lg hover:bg-red-100 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 transition-colors text-sm"
                    aria-label="Clear all products from inventory"
                >
                    <TrashIcon className="w-4 h-4" />
                    Clear All
                </button>
            </div>
        </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm text-left text-slate-600">
          <thead className="text-xs text-slate-700 uppercase bg-slate-100">
            <tr>
              <th scope="col" className="px-6 py-3">Product Name</th>
              <th scope="col" className="px-6 py-3">Production Date</th>
              <th scope="col" className="px-6 py-3">Expire Date</th>
              <th scope="col" className="px-6 py-3">Albaik Expire</th>
              <th scope="col" className="px-6 py-3 text-center">Quantity</th>
              <th scope="col" className="px-6 py-3 text-center">Remain Days</th>
              <th scope="col" className="px-6 py-3 text-right">Action</th>
            </tr>
          </thead>
          <tbody>
            {sortedProducts.map((product, index) => {
              const remainingDays = calculateRemainingDays(product.albaikExpire);
              const isFirstOverall = index === 0;
              const usageLabel = usageOrderMap.get(product.id);
              const isFirstInGroup = usageLabel === '1st Use';
              
              return (
                <tr key={product.id} className={`bg-white border-b border-slate-200 hover:bg-slate-50 transition-colors ${isFirstOverall ? 'bg-indigo-50' : ''}`}>
                  <td className="px-6 py-4 font-medium text-slate-900 whitespace-nowrap">
                    <div className="flex items-center gap-2">
                      {product.productName}
                      {usageLabel && 
                        <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${isFirstInGroup ? 'text-indigo-600 bg-indigo-100' : 'text-slate-600 bg-slate-100'}`}>
                            {usageLabel}
                        </span>
                      }
                    </div>
                  </td>
                  <td className="px-6 py-4">{formatDate(product.productionDate)}</td>
                  <td className="px-6 py-4">{formatDate(product.expireDate)}</td>
                  <td className="px-6 py-4 font-semibold">{formatDate(product.albaikExpire)}</td>
                  <td className="px-6 py-4 text-center font-semibold text-slate-900">
                    {formatQuantity(product.quantityCarton, product.quantityPiece, true)}
                  </td>
                  <td className="px-6 py-4 text-center">
                    <RemainingDaysDisplay days={remainingDays} />
                  </td>
                  <td className="px-6 py-4 text-right">
                    <button
                      onClick={() => onDeleteProduct(product.id)}
                      className="text-slate-400 hover:text-red-600 transition-colors p-1 rounded-full"
                      aria-label={`Delete ${product.productName}`}
                    >
                      <TrashIcon className="w-5 h-5" />
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      <div className="p-4 bg-slate-50 text-xs text-slate-500 flex items-center gap-2">
            <WarningIcon className="w-4 h-4 text-indigo-400" />
            <span>The <span className="font-bold text-indigo-600">highlighted row</span> indicates the next item to use overall. Items with the same name are ranked by priority (e.g., 1st Use, 2nd Use).</span>
      </div>
    </div>
  );
};

export default ProductList;
