
import React, { useState, useEffect } from 'react';
import { Product } from '../types';
import { PlusIcon } from './icons';
import { productNames } from '../data';

interface ProductFormProps {
  onAddProduct: (product: Omit<Product, 'id'>) => void;
}

// A map to store the date calculation rules for special products.
const productDateRules = new Map([
  // Group 1: +45 days expire, +34 days albaik
  ["Garlic Small", { expireDays: 45, albaikDays: 34 }],
  ["Garlic Large", { expireDays: 45, albaikDays: 34 }],
  ["Nugget Small", { expireDays: 45, albaikDays: 34 }],
  ["Nugget Large", { expireDays: 45, albaikDays: 34 }],
  ["Cocktail Small", { expireDays: 45, albaikDays: 34 }],
  ["Cocktail Large", { expireDays: 45, albaikDays: 34 }],
  ["Tahina Small", { expireDays: 45, albaikDays: 34 }],
  // Group 2: +45 days expire, +39 days albaik
  ["Garlic Super", { expireDays: 45, albaikDays: 39 }],
  ["Burger Super Regular", { expireDays: 45, albaikDays: 39 }],
  ["Burger Super Spicy", { expireDays: 45, albaikDays: 39 }],
  ["Tahina Super", { expireDays: 45, albaikDays: 39 }],
  ["Fish Super", { expireDays: 45, albaikDays: 39 }],
  // Group 3: +60 days expire, +44 days albaik
  ["Pickle Regular", { expireDays: 60, albaikDays: 44 }],
  ["Pickle Spicy", { expireDays: 60, albaikDays: 44 }],
  ["Sweet Pickle", { expireDays: 60, albaikDays: 44 }],
  ["Diced Pickle", { expireDays: 60, albaikDays: 44 }],
  // Group 4: +30 days expire, +20 days albaik
  ["Tartar Small", { expireDays: 30, albaikDays: 20 }],
  // Group 5: +30 days expire, +24 days albaik
  ["Tartar Super", { expireDays: 30, albaikDays: 24 }],
]);

/**
 * Adds a number of days to a date string (YYYY-MM-DD) and returns a new date string.
 * This function correctly handles dates to avoid timezone-related issues.
 * @param dateString The starting date in YYYY-MM-DD format.
 * @param days The number of days to add.
 * @returns The new date in YYYY-MM-DD format.
 */
const addDaysAndFormat = (dateString: string, days: number): string => {
    if (!dateString) return '';
    const parts = dateString.split('-').map(Number);
    // Month is 0-indexed in JS Date constructor
    const date = new Date(parts[0], parts[1] - 1, parts[2]);

    date.setDate(date.getDate() + days);

    const newYear = date.getFullYear();
    const newMonth = (date.getMonth() + 1).toString().padStart(2, '0');
    const newDay = date.getDate().toString().padStart(2, '0');

    return `${newYear}-${newMonth}-${newDay}`;
};

const calculateRemainingDays = (dateString: string): number => {
  if (!dateString) return 0;
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const parts = dateString.split('-').map(Number);
  const expiry = new Date(parts[0], parts[1] - 1, parts[2]);

  const diffTime = expiry.getTime() - today.getTime();
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
};

const RemainingDaysDisplay: React.FC<{ days: number }> = ({ days }) => {
    let textColor = 'text-green-600';
    if (days <= 0) {
        textColor = 'text-red-600';
    } else if (days <= 7) {
        textColor = 'text-amber-600';
    }

    return (
        <span className={`font-semibold ${textColor}`}>
            {days}
        </span>
    );
};

const ProductForm: React.FC<ProductFormProps> = ({ onAddProduct }) => {
  const [productName, setProductName] = useState('');
  const [productionDate, setProductionDate] = useState('');
  const [expireDate, setExpireDate] = useState('');
  const [albaikExpire, setAlbaikExpire] = useState('');
  const [quantityCarton, setQuantityCarton] = useState<number | ''>('');
  const [quantityPiece, setQuantityPiece] = useState<number | ''>('');
  const [isDateLocked, setIsDateLocked] = useState(false);
  const [remainingDays, setRemainingDays] = useState<number | null>(null);

  useEffect(() => {
    const rules = productDateRules.get(productName);
    setIsDateLocked(!!rules);

    if (rules) {
      if (productionDate) {
        setExpireDate(addDaysAndFormat(productionDate, rules.expireDays));
        setAlbaikExpire(addDaysAndFormat(productionDate, rules.albaikDays));
      } else {
        // Clear dates if production date is removed for a special product
        setExpireDate('');
        setAlbaikExpire('');
      }
    }
  }, [productName, productionDate]);
  
  useEffect(() => {
    if (albaikExpire) {
        setRemainingDays(calculateRemainingDays(albaikExpire));
    } else {
        setRemainingDays(null);
    }
  }, [albaikExpire]);

  const handleProductNameChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newProductName = e.target.value;
    setProductName(newProductName);

    // If switching to a non-special product, clear dependent dates to avoid stale data.
    if (!productDateRules.has(newProductName)) {
        setExpireDate('');
        setAlbaikExpire('');
    }
  };

  const handleAlbaikExpireChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newAlbaikDate = e.target.value;
    setAlbaikExpire(newAlbaikDate);
  }


  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cartonQty = Number(quantityCarton) || 0;
    const pieceQty = Number(quantityPiece) || 0;

    if (!productName || !productionDate || !expireDate || !albaikExpire) {
      alert('Please fill out all date and name fields.');
      return;
    }
    if (cartonQty <= 0 && pieceQty <= 0) {
      alert('Please provide a quantity for either cartons or pieces.');
      return;
    }

    onAddProduct({
      productName,
      productionDate,
      expireDate,
      albaikExpire,
      quantityCarton: cartonQty > 0 ? cartonQty : undefined,
      quantityPiece: pieceQty > 0 ? pieceQty : undefined,
    });

    // Reset form
    setProductName('');
    setProductionDate('');
    setExpireDate('');
    setAlbaikExpire('');
    setQuantityCarton('');
    setQuantityPiece('');
    setRemainingDays(null);
  };

  return (
    <div className="bg-white p-6 md:p-8 rounded-xl shadow-md border border-slate-200">
      <h2 className="text-2xl font-bold text-slate-700 mb-6">Add New Product</h2>
      <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-3">
          <label htmlFor="productName" className="block text-sm font-medium text-slate-600 mb-1">
            Product Name
          </label>
          <select
            id="productName"
            value={productName}
            onChange={handleProductNameChange}
            className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition bg-white"
            required
          >
            <option value="" disabled>Select a product</option>
            {productNames.map(name => (
              <option key={name} value={name}>{name}</option>
            ))}
          </select>
        </div>

        <div>
          <label htmlFor="productionDate" className="block text-sm font-medium text-slate-600 mb-1">
            Production Date
          </label>
          <input
            type="date"
            id="productionDate"
            value={productionDate}
            onChange={(e) => setProductionDate(e.target.value)}
            className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
            required
          />
        </div>

        <div>
          <label htmlFor="expireDate" className="block text-sm font-medium text-slate-600 mb-1">
            Expire Date {isDateLocked && <span className="text-xs text-indigo-600 font-semibold">(Auto)</span>}
          </label>
          <input
            type="date"
            id="expireDate"
            value={expireDate}
            onChange={(e) => setExpireDate(e.target.value)}
            className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition read-only:bg-slate-100 read-only:cursor-not-allowed"
            required
            readOnly={isDateLocked}
          />
        </div>

        <div>
          <label htmlFor="albaikExpire" className="block text-sm font-medium text-slate-600 mb-1">
            Albaik Expire Date {isDateLocked && <span className="text-xs text-indigo-600 font-semibold">(Auto)</span>}
          </label>
          <input
            type="date"
            id="albaikExpire"
            value={albaikExpire}
            onChange={handleAlbaikExpireChange}
            className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition read-only:bg-slate-100 read-only:cursor-not-allowed"
            required
            readOnly={isDateLocked}
          />
        </div>

        <div>
          <label htmlFor="quantityCarton" className="block text-sm font-medium text-slate-600 mb-1">
            Quantity (Cartons)
          </label>
          <input
            type="number"
            id="quantityCarton"
            value={quantityCarton}
            onChange={(e) => setQuantityCarton(e.target.value === '' ? '' : Number(e.target.value))}
            min="0"
            className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
            placeholder="e.g. 10"
          />
        </div>

        <div>
          <label htmlFor="quantityPiece" className="block text-sm font-medium text-slate-600 mb-1">
            Quantity (Pieces)
          </label>
          <input
            type="number"
            id="quantityPiece"
            value={quantityPiece}
            onChange={(e) => setQuantityPiece(e.target.value === '' ? '' : Number(e.target.value))}
            min="0"
            className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
            placeholder="e.g. 50"
          />
        </div>

        <div>
            <label htmlFor="remainingDays" className="block text-sm font-medium text-slate-600 mb-1">
                Remain Days
            </label>
            <div 
                id="remainingDays" 
                className="w-full h-[42px] px-4 py-2 border border-slate-200 rounded-lg bg-slate-100 flex items-center justify-center"
                aria-live="polite"
            >
                {remainingDays !== null ? <RemainingDaysDisplay days={remainingDays} /> : <span className="text-slate-400">-</span>}
            </div>
        </div>

        <div className="lg:col-span-3 flex items-end">
          <button
            type="submit"
            className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-indigo-600 text-white font-semibold rounded-lg shadow-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors"
          >
            <PlusIcon className="w-5 h-5" />
            Add Product
          </button>
        </div>
      </form>
    </div>
  );
};

export default ProductForm;
